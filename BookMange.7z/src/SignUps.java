import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class SignUps extends JDialog implements ActionListener {
	
	/*
	 * �̸�
	 * ��ȭ��ȣ
	 * */
	private boolean result;
	
	JTextField name;
	JTextField PhoneNumber;
	JButton SaveButton;
	
	public SignUps(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Sign Up");
		setLocation(450,150);
		setSize(300,400);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		Container contentpane = getContentPane();
		JPanel SignPanel = new JPanel();
		JPanel SavePanel = new JPanel();
		
		name = new JTextField();
		PhoneNumber =new JTextField();
		
		name.setText("�̸��� �Է��ϼ���");
		PhoneNumber.setText("��ȭ��ȣ�� �Է��ϼ���");
		SaveButton = new JButton("����");
		
		SaveButton.addActionListener(this);
		
		SignPanel.add(name,BorderLayout.NORTH);
		SignPanel.add(PhoneNumber,BorderLayout.SOUTH);
		SavePanel.add(SaveButton);
		
		contentpane.add(SignPanel, BorderLayout.CENTER);
        contentpane.add(SavePanel,BorderLayout.SOUTH);
	}
	
	public boolean showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		
	}
}
