import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class BookDeleteDialog extends JDialog implements ActionListener{

	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
