import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class BookPlusDialog extends JDialog implements ActionListener{
	
	/*
	 *��ȣ,����,�۰�,���ǻ�,�帣
	 * */
	private boolean result;
	
	JTextField BookNum;//��ȣ
	JTextField Bookname;//����
	JTextField Writer;//�۰�
	JTextField Company;//���ǻ�
	JTextField Genre;//�帣
	
	JButton SaveButton;
	
	public BookPlusDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Book Plus Dialog");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        
        Bookname.setText("å�̸��� �Է�");
        Writer.setText("�۰��� �Է�");
        Company.setText("���ǻ縦 �Է�");
        Genre.setText("�带�� �Է�");
	}
	
	public boolean showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
	}
	
}
