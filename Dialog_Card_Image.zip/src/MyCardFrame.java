import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MyCardFrame extends JFrame {
	JPanel cards;
	CardLayout cl;

	public MyCardFrame(String title, Point mainLoc) {
		super(title);
		setBounds(0, 0, 400, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocation(mainLoc.x + 160, mainLoc.y + 80);
		Container contentPane = this.getContentPane();

		cl = new CardLayout();
		cards = new JPanel(cl);

		JPanel card1 = new JPanel();
		card1.add(new JLabel("Card1"));
		cards.add(card1);

		JPanel card2 = new JPanel();
		card2.add(new JTextField("                  "));
		card2.add(new JButton("Card2"));
		cards.add(card2);

		cards.add(card2);

		contentPane.add(cards, BorderLayout.CENTER);

		JPanel btnPanel = new JPanel();
		JButton prev = new JButton("<");
		prev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.previous(cards);
			}
		});
		btnPanel.add(prev);
		JButton next = new JButton(">");
		next.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.next(cards);
			}
		});
		btnPanel.add(next);

		contentPane.add(btnPanel, BorderLayout.SOUTH);
	}
}
