import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class MyDialog extends JDialog implements ActionListener {
	private String result;
	
	private JTextField descBox;
	private JComboBox<String> colorList;
	private JButton btnOk;
	private JButton btnCancel;

	public MyDialog(Frame parent) {
		super(parent, "Enter data", true);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		Point loc = parent.getLocation();
		setLocation(loc.x + 80, loc.y + 80);

		JPanel panel = new JPanel();
		panel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.insets = new Insets(2, 2, 2, 2);
		gbc.fill = GridBagConstraints.HORIZONTAL;

		JLabel descLabel = new JLabel("Description:");
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		panel.add(descLabel, gbc);
		
		descBox = new JTextField(30);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 0;
		panel.add(descBox, gbc);
		
		JLabel colorLabel = new JLabel("Choose color:");
		gbc.gridwidth = 1;
		gbc.gridx = 0;
		gbc.gridy = 1;
		panel.add(colorLabel, gbc);
		
		String[] colorStrings = { "red", "green", "blue" };
		colorList = new JComboBox<String>(colorStrings);
		gbc.gridwidth = 1;
		gbc.gridx = 1;
		gbc.gridy = 1;
		panel.add(colorList, gbc);
		
		JPanel btnPanel = new JPanel();
		btnPanel.setLayout(new FlowLayout());
		
		btnOk = new JButton("Ok");
		btnOk.addActionListener(this);
		btnPanel.add(btnOk, gbc);
		
		btnCancel = new JButton("Cancel");
		btnCancel.addActionListener(this);
		btnPanel.add(btnCancel, gbc);
		
		gbc.gridwidth = 2;
		gbc.gridx = 0;
		gbc.gridy = 2;
		panel.add(btnPanel, gbc);
		
		getContentPane().add(panel);
		pack();
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == btnOk)
			result = descBox.getText() + ", " + (String) colorList.getSelectedItem();
		else
			result = null;
		
		dispose();
	}

	public String showDialog() {
		this.setVisible(true);
		return result;
	}
}