import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class MainFrame extends JFrame implements ActionListener {
	JButton dlgBtn, cardFrameBtn, imageFrameBtn;
	JLabel label;

	public MainFrame(String title) {
		super(title);
		setBounds(0, 0, 300, 200);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container contentPane = this.getContentPane();

		label = new JLabel();
		contentPane.add(label, BorderLayout.CENTER);

		dlgBtn = new JButton("Dialog");
		contentPane.add(dlgBtn, BorderLayout.WEST);
		dlgBtn.addActionListener(this);

		cardFrameBtn = new JButton("CardLayout");
		contentPane.add(cardFrameBtn, BorderLayout.EAST);
		cardFrameBtn.addActionListener(this);

		imageFrameBtn = new JButton("Image");
		contentPane.add(imageFrameBtn, BorderLayout.SOUTH);
		imageFrameBtn.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == dlgBtn) {
			MyDialog dlg = new MyDialog(this);
			String result = dlg.showDialog();
			if (result != null)
				label.setText(result);
		} else if (source == cardFrameBtn) {
			MyCardFrame frame = new MyCardFrame("CardLayout", getLocation());
			frame.setVisible(true);
		} else if (source == imageFrameBtn) {
			MyImageFrame frame = new MyImageFrame("Image", getLocation());
			frame.setVisible(true);
		}
	}

	public static void main(String[] args) {
		MainFrame frame = new MainFrame("Main Frame");
		frame.setVisible(true);
	}
}