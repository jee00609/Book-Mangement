import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MyImageFrame extends JFrame {

	public MyImageFrame(String title, Point mainLoc) {
		super(title);
		setBounds(0, 0, 400, 300);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLocation(mainLoc.x + 160, mainLoc.y + 80);
		Container contentPane = this.getContentPane();
		
		ImagePanel panel = new ImagePanel("fox.jpeg");

		contentPane.add(panel, BorderLayout.CENTER);
		
	}
}

class ImagePanel extends JPanel {
	BufferedImage image = null;
	private int w, h;

	ImagePanel(String path) {
		try {
			image = ImageIO.read(new File(path));
			w = image.getWidth();
			h = image.getHeight();
		} catch (IOException ioe) {
			System.out.println("Could not read the image.");
		}
	}

	public Dimension getPreferredSize() {
		return new Dimension(w, h);
	}

	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		if (image != null)
			g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
		System.out.println("paint");
	}
}
