import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class CLoginDialog extends JDialog implements ActionListener{ //Ŭ���̾�Ʈ �α���
	
	/*
	 * �̸�
	 * ��ȭ��ȣ
	 * Ȯ��
	 * 
	 * */
	
	private String result[] = null;
	
	JLabel helps = new JLabel("��ȭ��ȣ ���� 010-0000-0000");
	
	
	JTextField name = new JTextField(); // �̸��� ĥ ����
	JPasswordField ClientPassword = new JPasswordField(); //�н����带 ��ȭ��ȣ�� ����Ѵ�
	
	JLabel introName = new JLabel("�̸�");
	JLabel introCP = new JLabel("��ȭ��ȣ");
	
	JButton loginButton = new JButton("�α���"); //Ŭ���ϸ� �α��� ���� ����
	
 
    // ������
    public CLoginDialog(Frame parent) {
    	super(parent, "Enter data", true);
        setTitle("SK Library Client Login");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        Container contentpane = getContentPane();
        
        JPanel helpPanel = new JPanel();
        
        JPanel introducePanel = new JPanel();
        introducePanel.setLayout(new GridLayout(2, 2)); // ĥ���� �ΰ� ���� �ΰ�
        
        JPanel loginPanel = new JPanel();
        

        loginButton.addActionListener(this);
        
        helpPanel.add(helps);
        
        introducePanel.add(name);
        introducePanel.add(ClientPassword);
        introducePanel.add(introName);
        introducePanel.add(introCP);
        
        loginPanel.add(loginButton);
        
        contentpane.add(helps, BorderLayout.NORTH);//����
        contentpane.add(introducePanel, BorderLayout.CENTER);//�Է� �� ����
        contentpane.add(loginPanel,BorderLayout.SOUTH);//��ư
        
    }
    
	public String[] showDialog() {
		setVisible(true);
		return result;
	}
    
    public void actionPerformed(ActionEvent e) {
    	Object source = e.getSource();
    	if (source == loginButton) {
    		result = new String[2];
			result[0] = name.getText();	// username
			result[1] = ClientPassword.getText();	// userphone 
			dispose();
		}
		else
			result = null;
	}
    
    
}
