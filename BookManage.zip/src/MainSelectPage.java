import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;

import javax.swing.table.*;
import java.sql.*;

import javax.swing.*;
import javax.swing.event.ListSelectionListener;

public class MainSelectPage extends JFrame {
	///////////////////////////
	//card1
	CLoginDialog Clogin = null;
	MLoginDialog Mlogin = null;
	SignUpsFrame signups = null;
	
	//////////////////////////
	//card2(ManagerLogin)
	BookPlusDialog BookPlusD = null;
	BookDeleteDialog BookDeleteD = null;
	
	String clientName=null;
	
	JPanel cards;
	CardLayout cl;
	static final String MAIN = "Main";
	static final String ManagerBOOK = "ManagerBook";
	static final String ClientBOOK = "ClientBook";
	
	Connection dbConnection = null;
	
	//ȸ������ ���� ��ư �޼ҵ�
	void signUpsperform () {
		String result[] = signups.showDialog();
		if (result != null) {
			Statement stmt = null;
			try {
				stmt = dbConnection.createStatement();
				
				String query = "INSERT INTO tb_member (name, phone, rentcount) values ('" + result[0] + "', '"
								+ result[1] + "', 0);";
				System.out.println(query);
				int queryResult = stmt.executeUpdate(query);//�߿�!
				
				stmt.close();
			} catch (SQLException ex) { ex.printStackTrace(); }
		}
    }
	
	void bookplusperform() {
		String result[] = BookPlusD.showDialog();
		
		if (result != null) {
			Statement stmt = null;
			try {
				//insert into bookdb (Num, Name, Writer, Publisher, Genre, BookRent ) values (1,'õ���� �ݼ� :������ �����Ҽ�','������' ,'����','�����Ҽ�','Y');
				stmt = dbConnection.createStatement();
				String query = "INSERT INTO bookdb (num, name, writer, publisher, genre, bookrent ) values ("
						+ result[0] + ", '" + result[1] + "', '" +  result[2] + "', '" + result[3] + "', '"+ result[4] + "', 'Y');";
				System.out.println(query);
				int queryResult = stmt.executeUpdate(query);//�߿�!
				
				stmt.close();
			} catch (SQLException ex) { ex.printStackTrace(); }
		}
	}
	
	
	void bookdeleteperform() {
		int result = BookDeleteD.showDialog();
		
		if(result != 0) {
			Statement stmt = null;
			try {
				
				stmt = dbConnection.createStatement();
				String query = "DELETE FROM bookdb WHERE Num =" + result + ";";
				System.out.println(query);
				int queryResult = stmt.executeUpdate(query);//�߿�!
				
				stmt.close();
			} catch (SQLException ex) { ex.printStackTrace(); }
			
		}
		
	}
	
	void clientloginperform() {
		String result[] = Clogin.showDialog();
		if (result != null) {
			Statement stmt = null;
			try {
				//select * from goodsinfo where maker='�Ｚ' and price < 250000;
				stmt = dbConnection.createStatement();
				String query = "select * from tb_member where name="+"'"+result[0]+"'"+"and phone="+"'"+result[1]+"';";
				System.out.println(query);
				ResultSet rs = stmt.executeQuery(query);
				if (rs.next()) {
					int rentCount = rs.getInt("rentcount");
					System.out.println(result[0] + ", " + result[1] + ", " + rentCount);
					cl.show(cards, ClientBOOK);
				}
				stmt.close();
				} catch (SQLException ex) { ex.printStackTrace(); }
			}
		}
	
	String findClientName() {
		String result[] = Clogin.showDialog();
		return result[1];
		}
	
	
	//���ι�
	public static void main(String[] args) {

		new MainSelectPage();
	}
	
	
	// ������
    public MainSelectPage(){
    	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			dbConnection = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/malldb?useSSL=false", "root", "wkqkdjvmf");
		}
		
		catch (Exception ex) { ex.printStackTrace(); }
        setTitle("SK Library");
        setLocation(450,150);
        setSize(400,600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        
        /*�ȿ� �� ���빰���� �����ϴ� ������*/
        
        Container contentpane = getContentPane();
        //contentpane.setLayout(null); -->��ȸ�Ѵ� ������
        
		cl = new CardLayout();
		cards = new JPanel(cl);
		contentpane.add(cards, BorderLayout.CENTER);
		
		JPanel card1 = new JPanel();
		card1.setLayout(new BorderLayout());
		cards.add(card1, MAIN);
		
		JPanel card2 = new JPanel();
		card2.setLayout(new BorderLayout());
		cards.add(card2, ManagerBOOK);
		//card2.add(new JLabel("shaifnhsdoi"));
		
		JPanel card3 = new JPanel();
		card3.setLayout(new BorderLayout());
		cards.add(card3, ClientBOOK);
		
		
        //////////////////////////////////////////////////////////////////
		//card1
		
        /*�г� ���� ����*/
        JPanel pane1 = new JPanel(); //�׸� ���� ����
        JPanel pane2 = new JPanel(); // ���� �缭 �� �� ��ư
        pane2.setLayout(new GridLayout(2, 2));
        
        JPanel pane3 = new JPanel(); //ȸ������ ��ư ���� ��        
//        ImageIcon image = new ImageIcon("images/sunset.jpg");
//        JLabel jLabel = new JLabel("���ڿ�", image, SwingContents.CENTER);
        
        ImageIcon librarayImage = new ImageIcon("85178-200.png");
        JLabel label0 = new JLabel(librarayImage);
        
        JLabel label1= new JLabel("����"); //����
        JLabel label2= new JLabel("�缭"); //�缭
        
        JButton button1 = new JButton("����"); //����
        JButton button2 = new JButton("�缭"); //�缭
        JButton button3 = new JButton("�ű� ������ ȸ�������� ���ּ���"); //ȸ������
        
        /*���� �� �� ��� ��� ������ ����*/
        label1.setHorizontalAlignment(label1.CENTER); //���� ��� ���� 
        label2.setHorizontalAlignment(label1.CENTER); //�缭 ��� ����
        
        /*��ư ������ ���� ����*/
        button1.setPreferredSize(new Dimension(45, 28)); //����� �ٲ��� �ʴ´� ��?
        
        /*Panel�� �����ϴ� �κ�*/
        //pane1
        pane1.add(label0);
        
        //pane2
        pane2.add(button1);
        pane2.add(button2);
        pane2.add(label1);
        pane2.add(label2);
       
        
        //���� �α��� ��ư
        button1.addActionListener(new ActionListener() {	
        	
			@Override
			public void actionPerformed(ActionEvent e) {
				Clogin = new CLoginDialog(MainSelectPage.this);		
				System.out.println("Ŭ��");
				clientName=findClientName();
				System.out.println("�̸�"+clientName);
				clientloginperform();
			}
		});
        
        //�缭 �α��� ��ư
        button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Mlogin = new MLoginDialog(MainSelectPage.this);

				if (Mlogin.showDialog()) {
					cl.show(cards, ManagerBOOK);
				}
				
			}
		});
        
        //ȸ������ ��ư
        button3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				signups = new SignUpsFrame(MainSelectPage.this);
				signUpsperform();
				
			}
		});
        
        //pane3
        pane3.add(button3);
        
        /*ContentPane�� �����ϴ� �κ�*/
        card1.add(pane1, BorderLayout.NORTH);
        card1.add(pane2, BorderLayout.CENTER);
        card1.add(pane3, BorderLayout.SOUTH);
        
        
        /////////////////////////////////////////////////
        //card2 --> Manager Login ��  Book plus delete Page

        JPanel MPanel1 = new JPanel();
        JPanel MPanel2 = new JPanel();
        
        JButton BookPlus = new JButton("�߰�"); // ��ư Ŭ���� å �߰� ���̾�α�
        JButton BookDelete = new JButton("����");// ��ư Ŭ���� å ���� ������ ���̾�α�
        JButton MLogout = new JButton("�α׾ƿ�");//�α׾ƿ� Ŭ���� ù �������� ���ư���.
        JButton Mhistory = new JButton("���");
        
        
        //å �߰�
        BookPlus.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				BookPlusD = new BookPlusDialog(MainSelectPage.this);
				bookplusperform();
			}
		});
        
        //å ����
        BookDelete.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				BookDeleteD = new BookDeleteDialog(MainSelectPage.this);
				bookdeleteperform();
				
			}
		});
        
        //�α׾ƿ�
        MLogout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				cl.show(cards, MAIN);
				
			}
		});
        
        Mhistory.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String colNames[] = { "����ڹ�ȣ","å��ȣ","���" };
		        DefaultTableModel model = new DefaultTableModel(colNames,0);
		        JTable table = new JTable(model);
//				JOptionPane.showMessageDialog(null, new JScrollPane(table));
				
				//������ ���̽����� ���� �����;��Ѵ�...
				try {
			        Statement stmt = dbConnection.createStatement();
			        String query = "select * from history;";
			        System.out.println(query);
			        ResultSet rs;

					rs = stmt.executeQuery(query);
			        while (rs.next()) {
			        	String name = rs.getString("phoneNum");
					    int num = rs.getInt("bookNum");
					    String info = rs.getString("info"); 
					    Object row[] = { name, num, info };
					    model.addRow(row);
			        }
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(null, new JScrollPane(table));
			}
		});
        
        JLabel introBookPlus = new JLabel("�߰�");//å�߰���ư ����
        JLabel introBookDelete = new JLabel("����");//å������ư ����
        /*���� �� �� ��� ��� ������ ����*/
        introBookPlus.setHorizontalAlignment(label1.CENTER);
        introBookDelete.setHorizontalAlignment(label1.CENTER);
        
        MPanel1.setLayout(new GridLayout(2, 2));
        MPanel1.add(BookPlus);
        MPanel1.add(BookDelete);
        MPanel1.add(introBookPlus);
        MPanel1.add(introBookDelete);
        
        MPanel2.add(MLogout);
        MPanel2.add(Mhistory);
        
        card2.add(MPanel1, BorderLayout.CENTER);
        card2.add(MPanel2, BorderLayout.SOUTH);
        
        //////////////////////////////////////////////////////
        //card3 --> Client Login �� ����ȭ�� ���� �ؾ��ϴµ� ������... 

        
        JPanel CPanel1 = new JPanel();
        CPanel1.setLayout(new GridLayout(1,3));
        
        JPanel CPanel2 = new JPanel();
        CPanel2.setLayout(null);
        //CPanel2.setLayout(new GridLayout(6,0));
        
        JPanel CPanel3 = new JPanel();
        CPanel3.setLayout(new GridLayout(1,3));
        
        JButton kind = new JButton("å"); // ��ư Ŭ���� å->�۰�->���ǻ�
        JTextField bookSearchT = new JTextField(15);
        JButton bookSearchB = new JButton("�˻�"); // �˻��� kind bookSearchT�� ���� ��������.
        
        String colNames[] = { "�Ϸù�ȣ", "����", "�۰�", "���ǻ�","�帣","�뿩����" };
        DefaultTableModel model = new DefaultTableModel(colNames,0);
		
		JTable table = new JTable(model);
		table.setRowHeight(30);

		JScrollPane jsp = new JScrollPane(table);
		jsp.setBounds(0, 0, 400, 400);
		
        //������ ���̽����� ���� �����;��Ѵ�...
		try {
	        Statement stmt = dbConnection.createStatement();
	        String query = "select * from bookdb;";
	        System.out.println(query);
	        ResultSet rs;

			rs = stmt.executeQuery(query);
	        while (rs.next()) {
	        	int num = rs.getInt("Num");
	        	String name = rs.getString("Name");
	        	String writer = rs.getString("Writer"); 
	        	String publisher = rs.getString("Publisher");
	        	String genre = rs.getString("Genre");
	        	String bookRent = rs.getString("BookRent");
	        	Object row[] = { num, name, writer, publisher, genre, bookRent };
	        	model.addRow(row);
	        }
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		
		JTextField returnBookT = new JTextField(15);//�ݳ��� å ����
		JButton returnBookB = new JButton("�ݳ�");//�α׾ƿ� Ŭ���� ù �������� ���ư���.
        JButton CLogout = new JButton("�α׾ƿ�");//�α׾ƿ� Ŭ���� ù �������� ���ư���.
        JButton CHistory = new JButton("�����");
        
        ///////////////////////////////////////////////-->�Ʒ����� �׼� ������ ��Ʈ
        
        bookSearchB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String searchBWP = kind.getText();
				String userInput = bookSearchT.getText();
				//select * from goodsinfo where maker='�Ｚ' and price < 250000;
				
				if(searchBWP.equals("å")) {
					//������ ���̽����� ���� �����;��Ѵ�...
					try {
				        Statement stmt = dbConnection.createStatement();
				        
				        model.setRowCount(0);
				        
				        String query = "select * from bookdb where name like"+"'%"+userInput+"%'"+";";
				        System.out.println(query);
				        ResultSet rs;

						rs = stmt.executeQuery(query);
				        while (rs.next()) {
				        	int num = rs.getInt("Num");
				        	String name = rs.getString("Name");
				        	String writer = rs.getString("Writer"); 
				        	String publisher = rs.getString("Publisher");
				        	String genre = rs.getString("Genre");
				        	String bookRent = rs.getString("BookRent");
				        	Object row[] = { num, name, writer, publisher, genre, bookRent };
				        	model.addRow(row);
				        }
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				
				else if(searchBWP.equals("�۰�")) {
					//������ ���̽����� ���� �����;��Ѵ�...
					try {
				        Statement stmt = dbConnection.createStatement();
				        
				        model.setRowCount(0);
				        
				        String query = "select * from bookdb where writer like"+"'%"+userInput+"%'"+";";
				        System.out.println(query);
				        
				        ResultSet rs = stmt.executeQuery(query);
				        while (rs.next()) {
				        	int num = rs.getInt("Num");
				        	String name = rs.getString("Name");
				        	String writer = rs.getString("Writer"); 
				        	String publisher = rs.getString("Publisher");
				        	String genre = rs.getString("Genre");
				        	String bookRent = rs.getString("BookRent");
				        	Object row[] = { num, name, writer, publisher, genre, bookRent };
				        	model.addRow(row);
				        	//model.fireTableDataChanged();
				        	//model.fireTableRowsUpdated(colNames, 0);
				        }
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
					//table.repaint();
				}
				
				else if(searchBWP.equals("���ǻ�")) {
					//������ ���̽����� ���� �����;��Ѵ�...
					try {
				        Statement stmt = dbConnection.createStatement();
				        
				        model.setRowCount(0);
				        //whereClause = " WHERE name LIKE '%" + name + "%'";
				        String query = "select * from bookdb where publisher like"+"'%"+userInput+"%'"+";";
				        System.out.println(query);
				        ResultSet rs;

						rs = stmt.executeQuery(query);
				        while (rs.next()) {
				        	int num = rs.getInt("Num");
				        	String name = rs.getString("Name");
				        	String writer = rs.getString("Writer"); 
				        	String publisher = rs.getString("Publisher");
				        	String genre = rs.getString("Genre");
				        	String bookRent = rs.getString("BookRent");
				        	Object row[] = { num, name, writer, publisher, genre, bookRent };
				        	model.addRow(row);
				        }
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				
				else {
					//������ ���̽����� ���� �����;��Ѵ�...
					try {
				        Statement stmt = dbConnection.createStatement();
				        
				        model.setRowCount(0);
				        //whereClause = " WHERE name LIKE '%" + name + "%'";
				        String query = "select * from bookdb;";
				        System.out.println(query);
				        ResultSet rs;

						rs = stmt.executeQuery(query);
				        while (rs.next()) {
				        	int num = rs.getInt("Num");
				        	String name = rs.getString("Name");
				        	String writer = rs.getString("Writer"); 
				        	String publisher = rs.getString("Publisher");
				        	String genre = rs.getString("Genre");
				        	String bookRent = rs.getString("BookRent");
				        	Object row[] = { num, name, writer, publisher, genre, bookRent };
				        	model.addRow(row);
				        }
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				
				
			}
		});
        
        
        //��ư Ŭ���� å->�۰�->���ǻ�
        kind.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if(kind.getText().equals("å"))
					kind.setText("�۰�");
		        
				else if(kind.getText().equals("�۰�"))
						kind.setText("���ǻ�");
				
				else if(kind.getText().equals("���ǻ�"))
						kind.setText("å");
				
			}
		});
        
        //table action listener �κ�
        //������ ������ �ȴ� �� �̷����� 
        table.getSelectionModel().addListSelectionListener(
	            selectionEvent -> {
	                if (!selectionEvent.getValueIsAdjusting()
	                    && selectionEvent.getSource().equals(table.getSelectionModel())) {
	                	int booknum=(table.getSelectedRow()+1);
	                	System.out.println("if�� ����");
	                    System.out.println("Row index: " + (table.getSelectedRow()+1));
	                    
	                    Statement stmt = null;
	                    
	                    try {
	                    	System.out.println("try�� ����");
	                    	//select * from goodsinfo where maker='�Ｚ' and price < 250000;
	        				//update student set age = age + 4 where name like '������';
	                    	//insert into bookdb (Num, Name, Writer, Publisher, Genre, BookRent ) values (1,'õ���� �ݼ� :������ �����Ҽ�','������' ,'����','�����Ҽ�','Y');
	                    	stmt = dbConnection.createStatement();
	        				
	        				String query = "select * from bookdb where num="+"'"+booknum+"'"+"and bookrent = 'Y';"; 
	        				System.out.println(query);
	        				ResultSet rs = stmt.executeQuery(query);
	        				if (rs.next()) {
	        					System.out.println("if(rs.next)�� ����");
		        				/*String*/ query = "insert into rent(phoneNum,bookNum) values ("+"'"+clientName+"',"+booknum+");";
		        				System.out.println(query);
		        				int queryResult = stmt.executeUpdate(query);//�߿�!
		        				
		        				query="insert into history (phoneNum,bookNum,info) values ('"+clientName+"',"+booknum+","+"'����');";
		        				stmt.executeUpdate(query);
		        				
		        				query = "UPDATE bookdb SET BookRent='N' WHERE Num="+booknum+";";
		        				System.out.println(query);
		        				queryResult = stmt.executeUpdate(query);//�߿�!
		        				System.out.println("���� �� ��¥��");
		        				
		        				int row=model.getRowCount ();
		        				int col=model.getColumnCount();
//		        				System.out.println(row);
//		        				System.out.println(col);
//		        				model.fireTableCellUpdated(row,col);
		        				
		        				//������ ���̽����� ���� �����;��Ѵ�...
		    					try {
		    				        stmt = dbConnection.createStatement();
		    				        
		    				        System.out.println("�����ͺ��̽����� �� ������");
		    				        
		    				        query = "select * from bookdb;";
		    				        System.out.println(query);

		    						rs = stmt.executeQuery(query);
		    						model.setRowCount(0);
		    				        while (rs.next()) {
		    				        	int num = rs.getInt("Num");
		    				        	String name = rs.getString("Name");
		    				        	String writer = rs.getString("Writer"); 
		    				        	String publisher = rs.getString("Publisher");
		    				        	String genre = rs.getString("Genre");
		    				        	String bookRent = rs.getString("BookRent");
		    				        	Object row1[] = { num, name, writer, publisher, genre, bookRent };
		    				        	model.addRow(row1);
		    				        }
		    					} catch (SQLException e1) {
		    						e1.printStackTrace();
		    					}
	        				}
	        				else{
	        					if((table.getSelectedRow()+1)!=0)
	        						JOptionPane.showMessageDialog(MainSelectPage.this, "�̹� ����� �����Դϴ�.");
	        					System.out.println("�����̵̹�");
	        				}

	    					stmt.close();
	        			} catch (SQLException ex) { ex.printStackTrace(); }
	                    
	                }
	            }
	        );
        
        
        //�ݳ�
        returnBookB.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				String returnNum = returnBookT.getText();//-->å��ȣ
				int returnNum2=Integer.parseInt(returnNum);
				//clientname --> ����
				try {
					Statement stmt = dbConnection.createStatement();
					String query= "select * from rent where phoneNum="+"'"+clientName+"' and bookNum="+returnNum2+";";
					ResultSet rs = stmt.executeQuery(query);
					
					if(rs.next()) {
						System.out.println("ã��");
						
//						query="insert into history (phoneNum,bookNum,info) values ('"+clientName+"',"+returnNum2+","+"'�ݳ�');";
//						int queryResult = stmt.executeUpdate(query);//�߿�!
//        				stmt.executeUpdate(query);

        				query = "UPDATE bookdb SET BookRent='Y' WHERE Num="+returnNum2+";";
        				System.out.println(query);
        				int queryResult = stmt.executeUpdate(query);//�߿�!
        				System.out.println("�ݳ� ��");
        				
        				///////////////////////
        				//������ ���̽����� ���� �����;��Ѵ�...
    					try {
    				        stmt = dbConnection.createStatement();
    				        
    				        System.out.println("�����ͺ��̽����� �� ������");
    				        
    				        query = "select * from bookdb;";
    				        System.out.println(query);

    						rs = stmt.executeQuery(query);
    						model.setRowCount(0);
    				        while (rs.next()) {
    				        	int num = rs.getInt("Num");
    				        	String name = rs.getString("Name");
    				        	String writer = rs.getString("Writer"); 
    				        	String publisher = rs.getString("Publisher");
    				        	String genre = rs.getString("Genre");
    				        	String bookRent = rs.getString("BookRent");
    				        	Object row1[] = { num, name, writer, publisher, genre, bookRent };
    				        	model.addRow(row1);
    				        }
    					}catch (SQLException ex) { ex.printStackTrace(); }
        				///////////////////////
        				stmt.close();
					}

				} catch (SQLException ex) { ex.printStackTrace(); }
				
				Statement stmt;
				try {
					stmt = dbConnection.createStatement();
					
					String query="insert into history (phoneNum,bookNum,info) values ('"+clientName+"',"+returnNum2+","+"'�ݳ�');";
					//int queryResult = stmt.executeUpdate(query);//�߿�!
    				stmt.executeUpdate(query);
    				stmt.close();
				}catch (SQLException ex) { ex.printStackTrace(); }
				
			}
		});
        
        CHistory.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				String colNames[] = { "����ڹ�ȣ","å��ȣ","���" };
		        DefaultTableModel model = new DefaultTableModel(colNames,0);
		        JTable table = new JTable(model);
				
				//������ ���̽����� ���� �����;��Ѵ�...
				try {
			        Statement stmt = dbConnection.createStatement();
			        String query = query= "select * from history where phoneNum="+"'"+clientName+"';";
			        System.out.println(query);
			        ResultSet rs;

					rs = stmt.executeQuery(query);
			        while (rs.next()) {
			        	String name = rs.getString("phoneNum");
					    int num = rs.getInt("bookNum");
					    String info = rs.getString("info"); 
					    Object row[] = { name, num, info };
					    model.addRow(row);
			        }
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				JOptionPane.showMessageDialog(null, new JScrollPane(table));
				
			}
		});

        //�α׾ƿ�
        CLogout.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				clientName=null;
				cl.show(cards, MAIN);
				
			}
		});
        

        
        ////////////////////////////////////////////////
        CPanel1.add(kind);
        CPanel1.add(bookSearchT);
        CPanel1.add(bookSearchB);
        
//        for(int i=0; i<radio.length; i++){
//            CPanel1.add(radio[i]);
//        }
        
        CPanel2.add(jsp, BorderLayout.CENTER);
        CPanel2.setBackground(Color.pink);
        

        CPanel3.add(CLogout);
        CPanel3.add(returnBookT);
        CPanel3.add(returnBookB);
        CPanel3.add(CHistory);
        
        card3.add(CPanel1, BorderLayout.NORTH);
        card3.add(CPanel2,BorderLayout.CENTER);
        card3.add(CPanel3, BorderLayout.SOUTH);
        
        setVisible(true);
    }

}
