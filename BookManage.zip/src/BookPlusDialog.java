import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class BookPlusDialog extends JDialog implements ActionListener{
	
	/*
	 * �Ϸù�ȣ
	 * ����
	 * ����
	 * ���ǻ�
	 * �帣
	 * ���Ⱑ�ɿ���
	 * */
	private String result[] = null;
	
	//JTextField bookNum = new JTextField();//�Ϸù�ȣ
	JTextField bookName = new JTextField();//����
	JTextField writer = new JTextField();;//����
	JTextField company = new JTextField();;//���ǻ�
	JTextField genre = new JTextField();;//�帣
	
	JButton saveButton = new JButton("�߰�");//�߰�
	JButton cancelButton = new JButton("���")  ;//���
	
	public BookPlusDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Book Plus Dialog");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        Container contentpane = getContentPane();
		JPanel bookPlusPanel = new JPanel();
		JPanel savePanel = new JPanel();
        
        bookName.setText("å�̸��� �Է�");
        writer.setText("�۰��� �Է�");
        company.setText("���ǻ縦 �Է�");
        genre.setText("�帣�� �Է�");
        
        bookPlusPanel.add(bookName);
        bookPlusPanel.add(writer);
        bookPlusPanel.add(company);
        bookPlusPanel.add(genre);
        
        savePanel.add(saveButton);
        savePanel.add(cancelButton);
        
        contentpane.add(bookPlusPanel, BorderLayout.CENTER);
        contentpane.add(savePanel,BorderLayout.SOUTH);
	}
	
	public String[] showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		result = new String[5];
	}
	
}
