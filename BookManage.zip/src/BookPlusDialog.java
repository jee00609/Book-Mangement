import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class BookPlusDialog extends JDialog implements ActionListener{
	
	/*
	 * �Ϸù�ȣ
	 * ����
	 * ����
	 * ���ǻ�
	 * �帣
	 * ���Ⱑ�ɿ���
	 * */
	private String result[] = null;
	
	JTextField bookNum = new JTextField();//�Ϸù�ȣ
	JTextField bookName = new JTextField();//����
	JTextField writer = new JTextField();;//����
	JTextField company = new JTextField();;//���ǻ�
	JTextField genre = new JTextField();;//�帣
	
	JButton saveButton = new JButton("�߰�");//�߰�
	JButton cancelButton = new JButton("���")  ;//���
	
	public BookPlusDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Book Plus Dialog");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        Container contentpane = getContentPane();
		JPanel bookPlusPanel = new JPanel();
		JPanel savePanel = new JPanel();
        
		bookNum.setText("�Ϸù�ȣ �Է�");//0
        bookName.setText("å�̸��� �Է�");//1
        writer.setText("�۰��� �Է�");//2
        company.setText("���ǻ縦 �Է�");//3
        genre.setText("�帣�� �Է�");//4
        
        bookPlusPanel.add(bookNum);
        bookPlusPanel.add(bookName);
        bookPlusPanel.add(writer);
        bookPlusPanel.add(company);
        bookPlusPanel.add(genre);
        
        savePanel.add(saveButton);
        savePanel.add(cancelButton);
        
        saveButton.addActionListener(this);
        cancelButton.addActionListener(this);
        
        contentpane.add(bookPlusPanel, BorderLayout.CENTER);
        contentpane.add(savePanel,BorderLayout.SOUTH);
	}
	
	public String[] showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		
		if (source == saveButton) {
			result = new String[5];
			result[0]=bookNum.getText();
			result[1]=bookName.getText();
			result[2]=writer.getText();
			result[3]=company.getText();
			result[4]=genre.getText();
		}
		else
			result = null;
		
		dispose();
//		if(source == cancelButton) {
//			dispose();
//			setVisible(false);
//		}
	}
	
}
