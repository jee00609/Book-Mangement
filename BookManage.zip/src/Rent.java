import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Rent extends JDialog implements ActionListener{
	
	
	public Rent(Frame parent) {
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
	}
}
