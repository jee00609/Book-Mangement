import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.*;
import javax.print.attribute.standard.*;
import javax.swing.*;
import javax.swing.table.*;

public class SignUpsFrame extends JDialog implements ActionListener {
	
	/*
	 * �̸�
	 * ��ȭ��ȣ
	 * */
	private String result[] = null;
	
	JTextField name;
	JTextField PhoneNumber;
	JButton saveButton;
	JButton cancelButton;
	
	public SignUpsFrame(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Sign Up");
		setLocation(450,150);
		setSize(300,400);
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		
		Container contentpane = getContentPane();
		JPanel signPanel = new JPanel();
		JPanel savePanel = new JPanel();
		
		name = new JTextField();
		PhoneNumber =new JTextField();
		
		name.setText("�̸��� �Է��ϼ���");
		PhoneNumber.setText("��ȭ��ȣ�� �Է��ϼ���");
		saveButton = new JButton("����");
		cancelButton = new JButton("���");
		saveButton.addActionListener(this);
		
		signPanel.add(name,BorderLayout.NORTH);
		signPanel.add(PhoneNumber,BorderLayout.SOUTH);
		savePanel.add(saveButton);
		savePanel.add(cancelButton);
		
		contentpane.add(signPanel, BorderLayout.CENTER);
        contentpane.add(savePanel,BorderLayout.SOUTH);
	}
	
	public String[] showDialog() {
		setVisible(true);
		return result;
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == saveButton) {
			result = new String[2];
			result[0] = name.getText();	// username
			result[1] = PhoneNumber.getText();	// userphone 
			dispose();
		}
		else
			result = null;
		
		if(source == cancelButton) {
			dispose();
			setVisible(false);

		}
				
	}
	

}
