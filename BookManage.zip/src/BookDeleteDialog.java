import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class BookDeleteDialog extends JDialog implements ActionListener{

	public BookDeleteDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Book Delete Dialog");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
	}
}
