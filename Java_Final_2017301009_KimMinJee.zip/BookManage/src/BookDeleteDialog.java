import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;


import javax.swing.*;

public class BookDeleteDialog extends JDialog implements ActionListener{

	Connection dbConnection = null;
	
	private int result = 0;
	
	JTextField bookNum = new JTextField("�Ϸù�ȣ");//�Ϸù�ȣ
	JButton deleteButton = new JButton("����");//�߰�
	
	public BookDeleteDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Book Delete Dialog");
        setLocation(450,150);
        setSize(400,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        Container contentpane = getContentPane();
        
        JPanel bookDeletePanel = new JPanel();
		JPanel deletePanel = new JPanel();

		bookDeletePanel.add(bookNum);
		deletePanel.add(deleteButton);

		

		deleteButton.addActionListener(this);

		contentpane.add(bookDeletePanel,BorderLayout.NORTH);
		contentpane.add(deletePanel,BorderLayout.SOUTH);
		
	}
	
	public int showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		int num=0; // �ƿ� ���� ���ڷ� �ʱ�ȭ
		String numtext = bookNum.getText();
		num = Integer.parseInt(numtext);

		if(source == deleteButton) {
			result = num;
		}

		dispose();
		
	}
}
