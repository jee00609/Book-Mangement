import java.awt.*;
import javax.swing.*;

public class SignUps extends JDialog {
	
	public SignUps() {
		setTitle("Sign Up");
		setLocation(450,150);
		setSize(400,600);
		
		
		
	}
}
