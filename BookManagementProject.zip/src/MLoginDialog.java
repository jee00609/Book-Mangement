import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class MLoginDialog extends JDialog implements ActionListener{//�缭 �α���
	
	private boolean result;
	private String password="1234"; //���� �н�����
	
	JLabel pass;//����
	JPasswordField MangerPassword; //�н����� �Է�
	JButton bt; //Ŭ���ϸ� �α��� ���� ����
	
	public MLoginDialog(Frame parent) {
		super(parent, "Enter data", true);
		setTitle("Manager Login");
        setLocation(450,150);
        setSize(200,300);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        
        Container contentpane = getContentPane();
        JPanel MlPane1 = new JPanel();
        //MlPane1.setLayout(new GridLayout(2,2));
        
        JPanel MlPane2 = new JPanel();
        //MlPane2.setLayout(new GridLayout(2,2));
        
        pass = new JLabel("��й�ȣ�� �Է��ϼ���.");
        MangerPassword = new JPasswordField(5);
        
        bt= new JButton("Ȯ��");
       bt.addActionListener(this);
        
        MlPane1.add(pass,BorderLayout.WEST);
        MlPane1.add(MangerPassword,BorderLayout.EAST);
        MlPane2.add(bt,BorderLayout.SOUTH);
        
        contentpane.add(MlPane1, BorderLayout.CENTER);
        contentpane.add(MlPane2,BorderLayout.SOUTH);
        
        
	}
	
	public boolean showDialog() {
		setVisible(true);
		return result;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		String ispass = MangerPassword.getText();
		if(ispass.equals(password)) {
			result = true;
			System.out.println("password ok");
			dispose();
		}else {
			result = false;
		}
		//dispose();
	}

}
